package com.infy.bookingservice;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;




@Service
public class BookingService {
	
	@Autowired
	private BookingRepository bookrepo;
	@Autowired
	private ShowRepository showrepo;
	
	
	
	public Booking addBooking(Booking booking) {
        Integer seatsBooked=booking.getSeatsBooked();
        Integer showid=booking.getShowID().getShowId();
        Optional <Show> show=showrepo.findById(showid);
        Float ticketPrice=show.get().getTicketPrice();
        Integer seatsAvailable=show.get().getSeatsAvailable();
        Integer remainingseats=seatsAvailable-seatsBooked;
        show.get().setSeatsAvailable(remainingseats);
        System.out.println(remainingseats);
        System.out.println(ticketPrice);
        Float amount=(seatsBooked*ticketPrice);
        booking.setAmount(amount);
        booking.setStatus("BOOKED");
        return bookrepo.save(booking);
    }
	
	
	
	public List<Booking> getBookingsbytdate(String fromDate,String toDate){
        List<Booking> allbookings= new ArrayList<>();
        List<Booking> bookinglist= new ArrayList<>();
        bookrepo.findAll().forEach(allbookings::add);
       
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        Date startdate = null;
        Date enddate = null;
       
        try {
            startdate = dateFormat.parse(fromDate);
            enddate = dateFormat.parse(toDate);
        }
        catch (ParseException e) {
            e.printStackTrace();
        }
       
        for(Booking booking : allbookings){
           if(booking.getShowID().getShowDate().after(startdate)||booking.getShowID().getShowDate().before(enddate)||
                   booking.getShowID().getShowDate().equals(startdate)||booking.getShowID().getShowDate().equals(enddate)) {
               bookinglist.add(booking);
           }
        }
        return bookinglist;
       
    }

 

	
	public List<Booking> getBookings(){
		return (List<Booking>) bookrepo.findAll();
	}
	
	public Booking getBookingbyId(Integer id) {
		return bookrepo.findById(id).get();
	}
	
	public Booking deleteBooking(Integer id) {
		   
        Booking booking=getBookingbyId(id);
        Integer seatsBooked=booking.getSeatsBooked();
        Show show=booking.getShowID();
        Integer seatsAvailable=show.getSeatsAvailable();
        Integer remainingSeats=(seatsAvailable+seatsBooked);
        System.out.println(remainingSeats);
        show.setSeatsAvailable(remainingSeats);
        booking.setStatus("CANCELLED");
        return bookrepo.save(booking);
//        bookrepo.deleteById(id);
    }
	
	public List<Show> getAllShows(){
        return (List<Show>) showrepo.findAll();
    }
    
    public Optional<Show> findShow(Integer id) {        
        Optional<Show> show = showrepo.findById(id);
        return show;
    }
    
    public Show addShow(Show show) {
    	System.out.println(show.getMovieId().getMovieId());
        return showrepo.save(show);
    }
    
    public Show updateshowDetails(Integer id,Show show) {
        show.setShowId(id);
        return showrepo.save(show);
    }
    
    public Show getShow(Integer id) {
		return showrepo.findById(id).get();
	}
    
    public void deleteShow(Integer id) {      
        showrepo.deleteById(id);        
    }

    
    public List<Show> findShowByMoive(Integer movieId) {       
        List<Show> allshows = getAllShows();
        List<Show> shows = new ArrayList<>();
        for(Show show : allshows) {
            if(show.getMovieId().getMovieId().equals(movieId)) {
                shows.add(show);
            }
        }
        return shows;     
    }
    
    public List<Show> findShowByTheatre(Integer theatreId) {       
        List<Show> allshows = getAllShows();
        List<Show> shows = new ArrayList<>();
        for(Show show : allshows) {
            if(show.getTheatreId().getTheatreId().equals(theatreId)) {
                shows.add(show);
            }
        }
        return shows;     
    }
    
    public List<Booking> getUserBooking(String userName) {
    	List<Booking> allbooking = getBookings();
        List<Booking> bookings = new ArrayList<>();
        for(Booking book : allbooking) {
            if(book.getUserId().getUserName().equals(userName)) {
            	bookings.add(book);
            }
        }
        return bookings;     
    }
    
	

}
