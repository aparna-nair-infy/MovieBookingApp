import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import {Booking} from './booking';
import { UserService } from './user.service';
import { Show } from '../admin/show';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  userName:any;
  movieName:string;
  userId:any;
  searchtext:string;
  successMessage:string;
  errorMessage:string;
  movieId:any;
  theatreId:any;
  theatrename;String;
  amount:number;
  status:string;
  seatsBooked:number;
  showID:any;
  showTime:any;
  showDate:any;
  seatsAvailable:number;
  bookingId:number;
  bookShow:FormGroup;
  customload=true;
  getShow=false;
getBooking=false;
bukShow=false;
showsearch:Show[];
shows:Show[];
show:Show;
booking:Booking;
bookings:Booking[];
showmodal=false;
filled=true;
lowerm:string;
lowert:string;

constructor(private router:Router,private service:UserService, private formBuilder:FormBuilder) { 
  this.userName=sessionStorage.getItem('userName');
  // this.user_id=sessionStorage.getItem('user_id');
}

ngOnInit() :void {
  this.customload=true;
  this.showsearch=this.shows;

}
getShows(){
  this.service.getAllShows().subscribe(
    (response)=>{
      this.shows=response;
      this.showsearch=response;
      this.clear();
      console.log(response);

    },
    (error)=>{
      this.errorMessage=error.error.message;
    }
    )
    this.getShow=true;
    this.customload=false;

  }
  getBookings(){
    this.service.getAllBookings(this.userName).subscribe(
      (response)=>{
        this.bookings=response
        console.log(response);
  
      },
      (error)=>{
        this.errorMessage=error.error.message;
      }
      )
      this.getBooking=true;
      this.customload=false;
  }
  // cancelbukshow(){
  //   this.bukShow=false;
  //   this.getShow=true;

  // }
  goshow(){
    this.getShow=false;
    this.customload=true;
  }
  goBooking(){
    this.getBooking=false;
    this.customload=true;
  }
  cancelBooking(bookingId){
    var r=confirm("Are you sure you want to cancel?")
    if(r==true){
      this.service.cancelBooking(bookingId).subscribe(
        (response)=>{
          this.successMessage=response.responseMsg;
          alert("Booking cancelled successfully");
          this.getBookings();
          
        },
        (error)=>{
          this.errorMessage=error.message;
        }
      )
    } 
    this.getBookings();
  }
  book(m:Show){

    this.show=m;
this.bookShow=this.formBuilder.group({
  userId:[this.userName],
  showID:[this.show.showId,[Validators.required],null],
  movieName:[this.show.movieId.movieName,[Validators.required],null],
  theatrename:[this.show.theatreId.theatrename,[Validators.required],null],
  showDate:[this.show.showDate,[Validators.required],null],
  seatsAvailable:[this.show.seatsAvailable,[Validators.required],null],
  ticketPrice:[this.show.ticketPrice,[Validators.required],null],
  showTime:[this.show.showTime,[Validators.required],null],
  seatsBooked:[Validators.required]
})
this.getShow=false;
this.showmodal=true;
  }
  hide(){
    this.showmodal = false;
    this.clear();
    this.getShow=true;
  }
  confirmBook(seatsBooked:number){
    this.filled=true;
    if(this.bookShow.controls.seatsAvailable.value<seatsBooked){
      this.filled=false;
      console.log(seatsBooked);
      console.log(this.bookShow.controls.seatsAvailable.value);
    }
    else{
    // this.booking.userId=this.userName
    // this.booking.showID=this.bookShow.value.show_id
    // this.booking.seatsBooked=this.bookShow.value.seats

    this.userId=this.userName;
    console.log(this.userId);
    this.showID=this.bookShow.value.showID;
    // this.seatsBooked=this.bookShow.value.seatsBooked;
    console.log(seatsBooked);
    this.service.doBooking({userId:{userName:this.userId},showID:{showId:this.showID},seatsBooked}).subscribe((response)=>{
      this.successMessage=response.responseMsg;
      this.getBookings();
      alert("Booking done successfully");
    },
    (error)=>{
      this.errorMessage=error.message;
    })
    this.getBookings();
    this.showmodal=false;
  } 
  }
  search(abc){
    if(this.searchtext){
      this.showsearch=this.shows.filter(show=>{
        this.lowerm=show.movieId.movieName.toLowerCase();
        this.lowert=show.theatreId.theatrename.toLowerCase();
      
        return this.lowerm.indexOf(this.searchtext.toLowerCase())!=-1 ||
        this.lowert.indexOf(this.searchtext.toLowerCase())!=-1});
    }
    else{
      this.showsearch=this.shows;
    }
  }
  clear(){
    this.showsearch=this.shows;
    this.searchtext="";
  }

}



