import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Show } from '../admin/show';
import{Booking} from '../user/booking';


@Injectable({
  providedIn: 'root'
})
export class UserService {
  private url='http://localhost:8888/booking-service';

  constructor(private http:HttpClient) { }

  getAllShows():Observable<Show[]> {
    return this.http.get<Show[]>('http://localhost:8888/booking-service/Allshows');
  }
  getAllBookings(userId:any):Observable<Booking[]> {
    return this.http.get<Booking[]>(`${this.url}/userbooking/${userId}`);
  }
  searchbyMoT(MoT:string):Observable<any>{
    return this.http.get(`${this.url}/booking/search/${MoT}`,{responseType:'text'});
  }
  doBooking(data:any):Observable<any>{
    return this.http.post(`${this.url}/addbooking`,data);
  }
  cancelBooking(bookingId:number):Observable<any>{
    return this.http.delete<any>(`${this.url}/cancelbooking/${bookingId}`);
    
  }
  
}
