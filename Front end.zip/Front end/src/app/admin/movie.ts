export class Movie{
    public movieId:number;
    public movieName:string;
    public genre:string;
    public rating:string;
    public language:string;
}