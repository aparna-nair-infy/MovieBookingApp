export class Show{
    public showId:number;
    public theatreId:any;
    public movieId:any;
    public ticketPrice:number;
    public showTime:any;
    public showDate:any;
    public seatsAvailable:number;
}