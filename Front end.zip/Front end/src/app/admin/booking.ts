export class Booking{
    public bookingId:number;
    public userId:any;
    public showID:any;
    public seatsBooked:string;
    public amount:any;
    public status:string;
}