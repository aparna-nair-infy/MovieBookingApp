import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Login } from '../login/login';
import { Movie } from '../admin/movie';
import { Theatre } from '../admin/theatre';
import { Show } from '../admin/show';
import{Booking} from '../user/booking';






@Injectable({
  providedIn: 'root'
})
export class AdminService {
private url='http://localhost:8888';
  constructor(private http:HttpClient) { }
  
  getAllShows():Observable<Show[]> {
    return this.http.get<Show[]>('http://localhost:8888/booking-service/Allshows')
  }
  getAllMovies():Observable<Movie[]> {
    return this.http.get<Movie[]>('http://localhost:8888/movie-service/AllMovies')
  }
  getAllTheatres():Observable<Theatre[]> {
    return this.http.get<Theatre[]>('http://localhost:8888/theatre-service/AllTheatre')
  }
  deleteMovie(movieId:number):Observable<any>{
    return this.http.delete(`${this.url}/movie-service/movie/${movieId}`,{responseType:'text'})
  }
  deleteTheatre(theatreId:number):Observable<any>{
    return this.http.delete(`${this.url}/theatre-service/theatre/${theatreId}`,{responseType:'text'})
  }
  deleteShow(showId:number):Observable<any>{
    return this.http.delete(`${this.url}/booking-service/show/${showId}`,{responseType:'text'})
  }
  editTheatre(theatreId:number,data):Observable<any>{
    return this.http.put<any>(`${this.url}/theatre-service/updateTheatre/${theatreId}`,data);
  }
  editMovie(movieId:number,data):Observable<any>{
    return this.http.put<any>(`${this.url}/movie-service/updatemovie/${movieId}`,data);
  }
  editShow(showId:number,data):Observable<any>{
    return this.http.put<any>(`${this.url}/booking-service/updateshow/${showId}`,data);
  }
  addShow(data:any):Observable<any>{
    return this.http.post('http://localhost:8888/booking-service/addshow',data);
  }
  addMovie(data:any):Observable<any>{
    return this.http.post('http://localhost:8888/movie-service/add_movie',data);
  }
  addTheatre(data:any):Observable<any>{
    return this.http.post('http://localhost:8888/theatre-service/add_theatre',data);
  }
  addBookig(data:any):Observable<any>{
    return this.http.post('http://localhost:8888/booking-service/addbooking',data);
  }
  getAllBookings():Observable<Booking[]> {
    return this.http.get<Booking[]>('http://localhost:8888/booking-service/Allbooking')
  }
  
  searchbyMovie(movieId:string):Observable<any>{
    return this.http.get(`${this.url}/booking-service/getshow/${movieId}`,{responseType:'text'})
  }
  searchbyTheatre(theatreId:string):Observable<any>{
    return this.http.get(`${this.url}/booking-service/gtheatre/${theatreId}`,{responseType:'text'})
  }


}
