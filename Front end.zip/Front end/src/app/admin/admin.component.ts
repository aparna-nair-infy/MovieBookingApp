import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {AdminService} from './admin.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Movie } from './movie';
import { Theatre } from './theatre';
import { Show } from './show';
import {Booking} from '../user/booking';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
userName:string;
successMessage:string;
errorMessage:string;
movieId:number;
movieName:string;
genre:string;
rating:string;
language:string;
theatreId:number;
theatrename:string;
address:string;
capacity:number;
place:string;
showId:number;
theatreIdFK:any;
movieIdFK:any;
ticketPrice:number;
showTime:any;
showDate:any;
seatsAvailable:number;
bookingId:number;
addMovie:FormGroup;
editMovie:FormGroup;
addTheatre:FormGroup;
editTheatre:FormGroup;
addShow:FormGroup;
adminload=true;
getMovie= false;
getTheatre=false;
getShow=false;
getBooking=false;
adMovie=false;
adTheatre=false;
adShow=false;
ediMovie=false;
ediTheatre=false;
movies:Movie[];
theatres:Theatre[];
shows:Show[];
movie:Movie;
theatre:Theatre;
show:Show;
booking:Booking;
bookings:Booking[];
shid:string;
stat:string;
searchtext:string;
showsearch:Booking[];


  constructor(private router:Router,private service:AdminService, private formBuilder:FormBuilder) {
    this.userName=sessionStorage.getItem('userName');
   }

  ngOnInit(): void {
    this.adminload=true;
  }
  getShows(){
  this.service.getAllShows().subscribe(
    (response)=>{
      this.shows=response;
      console.log(response);

    },
    (error)=>{
      this.errorMessage=error.error.message;
    }
    )
    this.getShow=true;
    this.adminload=false;

  }
  getBookings(){
    this.service.getAllBookings().subscribe(
      (response)=>{
        this.bookings=response
        console.log(response);
  
      },
      (error)=>{
        this.errorMessage=error.error.message;
      }
      )
      this.getBooking=true;
      this.adminload=false;
  }
  getMovies(){
    this.service.getAllMovies().subscribe(
      (response)=>{
        this.movies=response;
        console.log(response);
      },
      (error)=>{
        this.errorMessage=error.error.message;
      }
      )
      this.getMovie=true;
      this.adminload=false;

  }
  getTheatres(){
    this.service.getAllTheatres().subscribe(
      (response)=>{
        this.theatres=response;
        console.log(response);

      },
      (error)=>{
        this.errorMessage=error.error.message;
      }
      )
      this.getTheatre=true;
      this.adminload=false;

  }
  canceladshow(){
    this.adShow=false;
    this.getShow=true;

  }
  canceladmovie(){
    this.adMovie=false;
    this.getMovie=true;

  }
  canceladtheatre(){
    this.adTheatre=false;
    this.getTheatre=true;
  }
  canceleditheatre(){
    this.ediTheatre=false;
    this.getTheatre=true;
  }
  canceledimovie(){
    this.ediMovie=false;
    this.getMovie=true;
  }
  goshow(){
    this.getShow=false;
    this.adminload=true;
  }
  gomovie(){
    this.getMovie=false;
    this.adminload=true;
  }
  gotheatre(){
    this.getTheatre=false;
    this.adminload=true;
  }
  goBooking(){
    this.getBooking=false;
    this.adminload=true;
  }

  deleteMovie(movieId:number){
    var r=confirm("Are you sure you want to delete?")
    if(r==true){
      this.service.deleteMovie(movieId).subscribe(
        (response)=>{
          this.successMessage=response.responseMsg;
          alert("Movie deleted successfully");
          this.getMovies();
          
        },
        (error)=>{
          this.errorMessage=error.message;
        }
      )
    } 
    this.getMovies();

  }
  deleteTheatre(theatreId:number){
    var r=confirm("Are you sure you want to delete?")
    if(r==true){
      this.service.deleteTheatre(theatreId).subscribe(
        (response)=>{
          this.successMessage=response.responseMsg;
          alert("Theatre deleted successfully");
          this.getTheatres()
               },
        (error)=>{
          this.errorMessage=error.message;
        }
      )
       
    } 
    this.getTheatres();
  }
  deleteShow(showId:number){
    var r=confirm("Are you sure you want to delete?")
    if(r==true){
      this.service.deleteShow(showId).subscribe(
        (response)=>{
          this.successMessage=response.responseMsg;
          alert("Show deleted successfully");
          this.getShows();
        },
        (error)=>{
          this.errorMessage=error.message;
        }
      )
    } 
    this.service.getAllShows().subscribe(
      (response)=>{
        this.shows=response;
        console.log(response);
  
      },
      (error)=>{
        this.errorMessage=error.error.message;
      }
      )
  }
  editmovie(movie:Movie){
    this.movie=movie;
    this.editMovie=this.formBuilder.group({
      movieId:[this.movie.movieId],
      movieName:[this.movie.movieName,[Validators.required],null],
      genre:[this.movie.genre,[Validators.required],null],
      rating:[this.movie.rating,[Validators.required],null],
      language:[this.movie.language,[Validators.required],null],
    })
  this.getMovie=false;
  this.ediMovie=true;
  }
edittheatre(theatre:Theatre){
  this.theatre=theatre;
  this.editTheatre=this.formBuilder.group({
    theatreId:[this.theatre.theatreId],
    theatrename:[this.theatre.theatrename,[Validators.required],null],
    address:[this.theatre.address,[Validators.required],null],
    capacity:[this.theatre.capacity,[Validators.required],null],
    place:[this.theatre.place,[Validators.required],null]
  })
  this.getTheatre=false;
  this.ediTheatre=true;
}
// editshow(show:Show){
//   this.show=show;
//   this.editShow=this.formBuilder.group({
//     showId:[this.show.showId],
//     movieName:[this.movie.movieName,[Validators.required],null],
//     theatrename:[this.theatre.theatrename,[Validators.required],null],
//     ticketPrice:[this.show.ticketPrice,[Validators.required],null],
//     showTime:[this.show.showTime,[Validators.required],null],
//     showDate:[this.show.showDate,[Validators.required],null],
//     seatsAvailable:[this.show.seatsAvailable,[Validators.required],null]
//   })
//   this.getShow=false;
//   this.editshow=true;
// }
// edishow(){
//   this.service.editShow(this.editShow.value.showId,this.editShow.value).subscribe(
//     response => {
//       console.log(response);
//       alert("Show edited successfully");
//       console.log("Show edited successfully");
//       this.getShows();
//     },
//     (error)=>{
//       this.errorMessage=error.error;
//       console.log("error");
//       this.getTheatres();
//     this.ediTheatre=false;
//     })
    
    

//}
editheatre(){
  this.service.editTheatre(this.editTheatre.value.theatreId,this.editTheatre.value).subscribe(
    response => {
      console.log(response);
      //this.service.getAllTheatres();
      alert("Theatre edited successfully");
      console.log("Theatre edited successfully");
      this.getTheatres();
    },
    (error)=>{
      this.errorMessage=error.error;
      console.log("error");
    })
    
    this.getTheatres();
    this.ediTheatre=false;
    
    

}
edimovie(){
  this.service.editMovie(this.editMovie.value.movieId,this.editMovie.value).subscribe(
    response => {
      console.log(response);
      alert("Movie edited successfully");
      console.log("Movie edited successfully");
      this.getMovies();
      this.getMovies();
      this.ediMovie=false;
    },
    (error)=>{
      this.errorMessage=error.error;
      console.log("error");
      
    })
    
    

}
addmovie(){
  this.addMovie=this.formBuilder.group({
   
    movieName:['',Validators.required],
      genre:['',Validators.required],
      rating:['',Validators.required],
      language:['',Validators.required]
  })
  this.getMovie=false;
  this.adMovie=true;
}
addtheatre(){
  this.addTheatre=this.formBuilder.group({
    
    theatrename:['',Validators.required],
    address:['',Validators.required],
    capacity:['',Validators.required],
    place:['',Validators.required]
    
  })
  this.getTheatre=false;
    this.adTheatre=true;
  
}
addshow() {
  this.service.getAllMovies().subscribe(
    (response) => {
      this.movies = response;
      console.log(response);
    },
    (error) => {
      this.errorMessage = error.error.message;
    }
  );
  this.service.getAllTheatres().subscribe(
    (response) => {
      this.theatres = response;
      console.log(response);
    },
    (error) => {
      this.errorMessage = error.error.message;
    }
  );
  this.addShow = this.formBuilder.group({
    // showDate: ["", [Validators.required, this.validateit]],
    showDate: ["", Validators.required],
    movieId: this.formBuilder.group({
      movieId: ["", Validators.required],
    }),
    theatreId: this.formBuilder.group({
      theatreId: ["", Validators.required],
    }),
    showTime: ["", Validators.required],
    ticketPrice: ["", Validators.required],
    seatsAvailable: ["", Validators.required],
  });
  this.getShow = false;
  this.adShow = true;
}
adshow() {
  console.log(this.addShow.value);
  this.service.addShow(this.addShow.value).subscribe(
    (response) => {
      this.successMessage = response.responseMsg;
      alert("Added show successfully");
      console.log("success");

    this.getShows()

    },
    (error) => {
      this.errorMessage = error.error;
      console.log("error");
    }
  );
  
  this.getShows()
  this.adShow = false;
}
admovie(){
  this.service.addMovie(this.addMovie.value).subscribe(
    (response)=>{
      this.successMessage=response.responseMsg;
      console.log("success");
      this.getMovies();
      this.adMovie=false;
    },
    (error)=>{
      this.errorMessage=error.error;
      console.log("error");
      
    }
  )
  this.getMovies();
  this.adMovie=false;

}
adtheatre(){
  this.service.addTheatre(this.addTheatre.value).subscribe(
    (response)=>{
      this.successMessage=response.responseMsg;
      console.log("success");
      this.getTheatres();
      this.adTheatre=false;
      
    },
    (error)=>{
      this.errorMessage=error.error;
      console.log("error");
      
    }
  )      
  this.getTheatres();
  this.adTheatre=false;  
}
validateit(c:FormControl){
  console.log(c.value);
  console.log(new Date(c.value).setHours(0,0,0,0));
  console.log(new Date().setHours(0,0,0,0));
  return new Date(c.value).setHours(0,0,0,0)>new Date().setHours(0,0,0,0)?null:{dateError:{message:"Invalid date"}}
}
search(abc){
  if(this.searchtext){
    this.showsearch=this.bookings.filter(booking=>{
      //this.shid=booking.show_id.toString();
      this.stat=booking.status.toLowerCase();
    
      // return this.shid.indexOf(this.searchtext)!=-1 ||
      // this.stat.indexOf(this.searchtext.toLowerCase())!=-1});
      return this.stat.indexOf(this.searchtext.toLowerCase())!=-1});
  }
  else{
    this.showsearch=this.bookings;
  }
}
clear(){
  this.showsearch=this.bookings;
  this.searchtext="";
}
}
