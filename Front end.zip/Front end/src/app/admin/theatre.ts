export class Theatre{
    public theatreId:number;
    public theatrename:string;
    public address:string;
    public capacity:number;
    public place:string;
}