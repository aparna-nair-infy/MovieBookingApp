export class Login{
    public userName:string;
    public password:string;
    public role:string;
    public phoneno:string;
    public email:string;

}