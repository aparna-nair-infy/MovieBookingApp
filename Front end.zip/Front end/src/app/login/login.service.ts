import { Injectable } from '@angular/core';
import {HttpClient, HttpErrorResponse} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Login } from './login';
@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http: HttpClient) { }
  base_url="http://localhost:8888/user-service";

  getAllUser(): Observable<Login[]> {
    // return this.http.get<Login[]>('assets/users/users.json');
    return this.http.get<Login[]>('${this.base_url}/');
  }
  login(data):Observable<any>{
    return this.http.post<any>(`${this.base_url}/login`,data);
  }
  addUser(data):Observable<any>{
    return this.http.post<any>(`${this.base_url}/AddNewUsers`,data);
  }


  //  getCustomerDetails(data,username):Observable<any>{
  //    return this.http.put<any>(`${this.base_url}/editPlan/${username}`,data);
  //  }

  private handleError(err: HttpErrorResponse) {
    console.error(err);
    return Observable.throw(err.error() || 'Server error');
  }
}
