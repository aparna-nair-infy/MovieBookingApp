import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LoginService } from './login.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm:FormGroup;
  registerForm:FormGroup;
  //users:any[]; 
  valid = true;
  //isLoggedIn = 'false';
  //loggedIn:string = 'false';
  userName:string;
  password:string;
  phoneno:any;
  email:string;
  errorMessage: string;
  successMessage: string;
  role:string;
  register= false;
  login= true;
  constructor(private fb:FormBuilder, private loginService: LoginService, private router:Router) {
    //this.loginService.getUsers().subscribe(users => this.users = users);
  }

  ngOnInit() {
    if(sessionStorage.getItem('isLoggedIn')=='true'){
      if(sessionStorage.getItem('userName')=='admin'){
        this.router.navigate(['/admin']);
      }
      else{
        this.router.navigate(['/user/:userName']);
      }
    }
    this.loginForm = this.fb.group({
      userName:['',Validators.required],
      password:['',Validators.required]
    }); 

  
    this.registerForm=this.fb.group({
      userName:['',Validators.required],
      password:['',[Validators.required ,Validators.pattern(/(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{5,}/),Validators.maxLength(9)]],
      phoneno:['',[Validators.required, Validators.min(1000000000), Validators.max(9999999999)]],
      email:['',[Validators.email,Validators.required]],
    })
  
  }

  onSubmit(){
    this.valid = true;
    this.register=false;
    this.userName=this.loginForm.value.userName;
    this.password=this.loginForm.value.password;
    this.loginService.login({userName:this.userName,password:this.password}).subscribe(
      (response)=>{
        console.log("successful login");
        console.log(response);
        this.successMessage="Login Successful";
        this.role=response.role;
        sessionStorage.setItem("userName",response.userName);
        // sessionStorage.setItem("user_id",response.user_id);

        // if(this.role=="admin"){
        //   console.log("Admin");
        //   this.router.navigate(['/admin'])
        // }
        // else{
        //   console.log("customer");
        //   this.router.navigate(['/customer'])
        // }
        if(this.role=="user"){
          // this.router.navigate(['/customer',this.user_name,this.user_id]);
          this.router.navigate(['/user',this.userName]);
          alert("Login Successfully!");

        }
        else{
          this.router.navigate(['/admin'])
          alert("Admin Login Successfully!");
        }
       
      },
      (error)=>{
        this.errorMessage=error.message;
        console.log("Some error has occured");
        this.valid = false;
      }
    )
  }

  registerUser(){
    this.login=false;
    this.register=true;
  }

  addUser(){
    this.login=true;
    this.register=false;
    this.userName=this.registerForm.value.userName;
    this.password=this.registerForm.value.password;
    this.phoneno=this.registerForm.value.phoneno;
    this.email=this.registerForm.value.email;
    this.role=this.registerForm.value.role;
    this.loginService.addUser({userName:this.userName,password:this.password,phoneno:this.phoneno,email:this.email}).subscribe(
      (response)=>{
        this.successMessage=response.responseMessage;
        alert("Registered successfully.Login!");
      },
      (error)=>{
        this.errorMessage=error.message;
        alert("Enter Valid details");
      }
    )
  }



}