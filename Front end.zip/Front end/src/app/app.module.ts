import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HttpClientModule } from '@angular/common/http';
//import { AdminComponent } from './admin/admin.component';
import {DatePipe} from '@angular/common';
//import { AdminService } from './admin/admin.service';
import { LoginService } from './login/login.service';
import { UserComponent } from './user/user.component';
import { AdminComponent } from './admin/admin.component';
import { UserService } from './user/user.service';
import { AdminService } from './admin/admin.service';

//import { CustomerService } from './customer/customer.service';
//import { CustomerComponent } from './customer/customer.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    UserComponent,
    AdminComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    
  ],
  providers: [DatePipe,LoginService,UserService,AdminService],
  bootstrap: [AppComponent]
})
export class AppModule { }
