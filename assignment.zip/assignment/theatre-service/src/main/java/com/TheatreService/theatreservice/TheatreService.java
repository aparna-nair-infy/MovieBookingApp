package com.TheatreService.theatreservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class TheatreService {

	@Autowired
	private TheatreRepository repo;
	
	public Theatre addTheatre(Theatre theatre) {
		return repo.save(theatre);
	}

	public List<Theatre> getTheatre() {
		return (List<Theatre>) repo.findAll();
	}

	public Theatre getTheatre(Integer id) {
		return repo.findById(id).get();
	}

	public List<Theatre> getTheatreByTheatrename(String theatrename) {
		return (List<Theatre>) repo.findByTheatrename(theatrename);
	}
	
	public void deleteByTheatreId(Integer id) {
		repo.deleteById(id);
	}
	
	public Theatre updateTheatre(Integer id,Theatre theatre) {
		theatre.setTheatreId(id);
		return repo.save(theatre);
	}
}
