package com.UserService.userservice;

 

public class Login {
    
    private String userName;
    private String password;
//    private String role;
//    public String getRole() {
//        return role;
//    }
//    public void setRole(String role) {
//        this.role = role;
//    }
    
    public String getPassword() {
        return password;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    
    public Login() {
        super();
    }

 

}